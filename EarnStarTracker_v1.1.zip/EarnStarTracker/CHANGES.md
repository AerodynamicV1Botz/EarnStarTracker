# EarnStar Tracker v1.1 - changes

## Branding
- Logo added as app launcher icon (all densities + Android 8+ adaptive icon, navy background #010928).
- Splash screen shows the real EarnStar Tracker logo for ~1.2 s on startup.
- Logo available as res/drawable-nodpi/earnstar_tracker_logo.png for later use (reports, About).
- App name is now "EarnStar Tracker".

## No hardcoded work
- Sample data (Sewing / Packaging / Print A-B) completely removed: loader, clear button, and all references.
- Default unit is no longer "Dozen"; the app starts with no works.
- First-run screen says "No works yet / Create your first work to start tracking."
- "+ New Work" wording replaces "Add work type". No example work names in fields.
- Unit suggestions are generic (Pieces, Dozen, Boxes, Bags, Kg, Meters, Hours, Units).

## Multiplier (base quantity x multiplier)
- Each work can define an optional multiplier name (e.g. Sets, Batches). Blank = off.
- When on, the entry form shows: "Calculated total: 16 x 5 Sets = 80 dozen".
- Work cards, day timeline, and work detail show base x multiplier = calculated total.
- Statistics, averages, day state and targets all use the calculated total (one function: totalFor()).
- Works without a multiplier behave exactly as before, so old records keep their meaning.

## Data / migration
- Room database version 1 -> 2 with a proper Migration (ALTER TABLE adds multiplierLabel). No destructive fallback.
- Backup JSON now includes multiplierLabel. Old backups still restore (field is optional).

## Empty-state / Home
- Home shows "No work recorded today." with an Add Work button when empty.

## NOT yet implemented from the 40-point spec
Start/Stop timers, custom fields and field enable/required flags, breakdown matching warnings beyond the existing one,
permanent reference notes, custom units, calculator, PNG/PDF report export, search of references, dark-theme redesign,
My Works screen with archive/duplicate, and the new dashboard layout. These need a larger rewrite and are planned as the next version.
