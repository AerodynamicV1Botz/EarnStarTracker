package com.earnstar.tracker

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "categories")
data class WorkCategory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val unit: String,
    val dailyTarget: Double? = null, val weeklyTarget: Double? = null, val monthlyTarget: Double? = null,
    val description: String = "", val active: Boolean = true, val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis(),
    /** Optional multiplier name (e.g. "Sets"). Null = no multiplier; quantity is used as-is. */
    val multiplierLabel: String? = null
)

/** One row per calendar day (primary key = epoch day). Holds start/end, break and the daily note. */
@Entity(tableName = "sessions")
data class DailySession(
    @PrimaryKey val date: Long,
    val startMs: Long? = null, val endMs: Long? = null,
    val breakMin: Int = 0, val note: String = "",
    val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "entries", indices = [Index("date"), Index("categoryId")])
data class WorkEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long, val categoryId: Long, val quantity: Double,
    val sets: Double? = null, val design: String = "",
    val durationMin: Int? = null, val startMs: Long? = null, val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "breakdowns", indices = [Index("entryId")],
    foreignKeys = [ForeignKey(entity = WorkEntry::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE)]
)
data class WorkBreakdown(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long, val label: String, val quantity: Double
)

/** A classified block of non-work time: Break / Other work / Personal / Waiting. */
@Entity(tableName = "blocks", indices = [Index("date")])
data class WorkBreak(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long, val minutes: Int, val type: String,
    val startMs: Long? = null, val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface TrackerDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder, id") fun categories(): Flow<List<WorkCategory>>
    @Query("SELECT * FROM entries") fun entries(): Flow<List<WorkEntry>>
    @Query("SELECT * FROM breakdowns") fun breakdowns(): Flow<List<WorkBreakdown>>
    @Query("SELECT * FROM sessions") fun sessions(): Flow<List<DailySession>>
    @Query("SELECT * FROM blocks") fun blocks(): Flow<List<WorkBreak>>

    @Insert suspend fun insertCategory(c: WorkCategory): Long
    @Update suspend fun updateCategory(c: WorkCategory)
    @Query("DELETE FROM categories WHERE id=:id") suspend fun deleteCategory(id: Long)
    @Query("SELECT COUNT(*) FROM entries WHERE categoryId=:id") suspend fun entryCount(id: Long): Int

    @Insert suspend fun insertEntry(e: WorkEntry): Long
    @Update suspend fun updateEntry(e: WorkEntry)
    @Query("DELETE FROM entries WHERE id=:id") suspend fun deleteEntry(id: Long)
    @Insert suspend fun insertBreakdowns(l: List<WorkBreakdown>)
    @Query("DELETE FROM breakdowns WHERE entryId=:id") suspend fun deleteBreakdowns(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSession(s: DailySession)
    @Insert suspend fun insertBlock(b: WorkBreak): Long
    @Query("DELETE FROM blocks WHERE id=:id") suspend fun deleteBlock(id: Long)

    @Query("DELETE FROM entries") suspend fun clearEntries()
    @Query("DELETE FROM sessions") suspend fun clearSessions()
    @Query("DELETE FROM blocks") suspend fun clearBlocks()
    @Query("DELETE FROM categories") suspend fun clearCategories()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCategories(l: List<WorkCategory>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putEntries(l: List<WorkEntry>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBreakdowns(l: List<WorkBreakdown>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSessions(l: List<DailySession>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putBlocks(l: List<WorkBreak>)
}

/** v1 -> v2: adds the optional multiplier label to works. Existing data is kept untouched. */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE categories ADD COLUMN multiplierLabel TEXT")
    }
}

@Database(
    entities = [WorkCategory::class, DailySession::class, WorkEntry::class, WorkBreakdown::class, WorkBreak::class],
    version = 2, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TrackerDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "tracker.db")
                .addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    private fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is String -> e.putString(k, v)
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
        }
        e.apply()
    }
    var theme by mutableStateOf(sp.getString("theme", "SYSTEM") ?: "SYSTEM"); private set
    var hour24 by mutableStateOf(sp.getBoolean("hour24", false)); private set
    var appName by mutableStateOf(sp.getString("appName", "EarnStar Tracker") ?: ""); private set
    var defaultUnit by mutableStateOf(sp.getString("defaultUnit", "") ?: ""); private set
    var defaultCat by mutableStateOf(sp.getLong("defaultCat", -1L)); private set
    var reminderOn by mutableStateOf(sp.getBoolean("reminderOn", false)); private set
    var reminderHour by mutableStateOf(sp.getInt("reminderHour", 20)); private set
    var reminderMin by mutableStateOf(sp.getInt("reminderMin", 0)); private set
    var setupDone by mutableStateOf(sp.getBoolean("setupDone", false)); private set

    fun putTheme(v: String) { theme = v; put("theme", v) }
    fun putHour24(v: Boolean) { hour24 = v; put("hour24", v) }
    fun putAppName(v: String) { appName = v; put("appName", v) }
    fun putDefaultUnit(v: String) { defaultUnit = v; put("defaultUnit", v) }
    fun putDefaultCat(v: Long) { defaultCat = v; put("defaultCat", v) }
    fun putReminderOn(v: Boolean) { reminderOn = v; put("reminderOn", v) }
    fun putReminderTime(h: Int, m: Int) { reminderHour = h; reminderMin = m; put("reminderHour", h); put("reminderMin", m) }
    fun putSetupDone(v: Boolean) { setupDone = v; put("setupDone", v) }
}
