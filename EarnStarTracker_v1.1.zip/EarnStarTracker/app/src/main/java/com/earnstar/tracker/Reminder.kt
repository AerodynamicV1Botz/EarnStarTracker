package com.earnstar.tracker

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.*
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminder", "Daily reminder", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, "reminder")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Have you recorded today's work?")
            .setContentText("Open EarnStar Tracker and add today's entries.")
            .setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(1, n)
        return Result.success()
    }
}

object Reminder {
    fun apply(c: Context, p: Prefs) {
        val wm = WorkManager.getInstance(c)
        if (!p.reminderOn) { wm.cancelUniqueWork("daily"); return }
        val now = LocalDateTime.now()
        var t = now.toLocalDate().atTime(p.reminderHour, p.reminderMin)
        if (!t.isAfter(now)) t = t.plusDays(1)
        val delay = Duration.between(now, t).toMillis()
        wm.enqueueUniquePeriodicWork(
            "daily", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
        )
    }
}
