EarnStar Tracker - Android project (Kotlin + Jetpack Compose + Room)

BUILD ON YOUR PC
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select the EarnStarTracker folder.
3. Wait for "Gradle sync" to finish (needs internet once).
4. Run it on a phone (USB debugging on) or an emulator with the green Run button.
5. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file appears under app/build/outputs/apk/debug/.

If Android Studio says the Gradle wrapper is missing (gradlew / gradle-wrapper.jar),
open the Terminal inside the project folder and run:
   gradle wrapper --gradle-version 8.9
(or install Gradle 8.9, or create a new empty Android project once and copy its gradlew,
gradlew.bat and gradle/wrapper folder into this project).

UPLOAD TO GITHUB
  git init
  git add .
  git commit -m "EarnStar Tracker v1.1"
  git branch -M main
  git remote add origin https://github.com/<you>/EarnStarTracker.git
  git push -u origin main
The included .gitignore keeps build output and local.properties out of GitHub.

DATA
All data is stored only on the phone (Room database, file tracker.db).
Existing data is preserved on upgrade (database version 1 -> 2 migration).
Use Settings > Export JSON backup regularly.
