package com.earnstar.tracker

import org.json.JSONArray
import org.json.JSONObject

class Parsed(
    val cats: List<WorkCategory>, val entries: List<WorkEntry>, val bds: List<WorkBreakdown>,
    val sessions: List<DailySession>, val blocks: List<WorkBreak>
)

private fun JSONObject.dbl(k: String): Double? = if (!has(k) || isNull(k)) null else getDouble(k)
private fun JSONObject.lng(k: String): Long? = if (!has(k) || isNull(k)) null else getLong(k)
private fun JSONObject.int(k: String): Int? = if (!has(k) || isNull(k)) null else getInt(k)
private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private val NIL: Any = JSONObject.NULL

fun toJson(d: AppData): String {
    val o = JSONObject()
    o.put("app", "EarnStarTracker"); o.put("version", 1); o.put("exportedAt", System.currentTimeMillis())
    o.put("categories", JSONArray().also { a -> d.cats.forEach { c -> a.put(JSONObject()
        .put("id", c.id).put("name", c.name).put("unit", c.unit)
        .put("dailyTarget", c.dailyTarget ?: NIL).put("weeklyTarget", c.weeklyTarget ?: NIL).put("monthlyTarget", c.monthlyTarget ?: NIL)
        .put("description", c.description).put("active", c.active).put("sortOrder", c.sortOrder)
        .put("createdAt", c.createdAt).put("updatedAt", c.updatedAt)) } })
    o.put("entries", JSONArray().also { a -> d.entries.forEach { e -> a.put(JSONObject()
        .put("id", e.id).put("date", e.date).put("categoryId", e.categoryId).put("quantity", e.quantity)
        .put("sets", e.sets ?: NIL).put("design", e.design).put("durationMin", e.durationMin ?: NIL)
        .put("startMs", e.startMs ?: NIL).put("notes", e.notes).put("createdAt", e.createdAt).put("updatedAt", e.updatedAt)) } })
    o.put("breakdowns", JSONArray().also { a -> d.breakdowns.forEach { b -> a.put(JSONObject()
        .put("id", b.id).put("entryId", b.entryId).put("label", b.label).put("quantity", b.quantity)) } })
    o.put("sessions", JSONArray().also { a -> d.sessions.forEach { s -> a.put(JSONObject()
        .put("date", s.date).put("startMs", s.startMs ?: NIL).put("endMs", s.endMs ?: NIL)
        .put("breakMin", s.breakMin).put("note", s.note).put("createdAt", s.createdAt).put("updatedAt", s.updatedAt)) } })
    o.put("blocks", JSONArray().also { a -> d.blocks.forEach { b -> a.put(JSONObject()
        .put("id", b.id).put("date", b.date).put("minutes", b.minutes).put("type", b.type)
        .put("startMs", b.startMs ?: NIL).put("note", b.note).put("createdAt", b.createdAt)) } })
    return o.toString(2)
}

/** Fully parses and validates a backup WITHOUT touching the database. Throws with a readable message on any problem. */
fun parseBackup(text: String): Parsed {
    val o = JSONObject(text)
    require(o.optString("app") == "EarnStarTracker") { "this is not an EarnStar Tracker backup" }
    require(o.optInt("version", 0) == 1) { "unsupported backup version" }
    val cats = o.getJSONArray("categories").objs().map { j ->
        WorkCategory(j.getLong("id"), j.getString("name"), j.getString("unit"), j.dbl("dailyTarget"), j.dbl("weeklyTarget"),
            j.dbl("monthlyTarget"), j.optString("description", ""), j.optBoolean("active", true), j.optInt("sortOrder", 0),
            j.optLong("createdAt", 0), j.optLong("updatedAt", 0))
    }
    val entries = o.getJSONArray("entries").objs().map { j ->
        WorkEntry(j.getLong("id"), j.getLong("date"), j.getLong("categoryId"), j.getDouble("quantity"), j.dbl("sets"),
            j.optString("design", ""), j.int("durationMin"), j.lng("startMs"), j.optString("notes", ""),
            j.optLong("createdAt", 0), j.optLong("updatedAt", 0))
    }
    val bds = o.getJSONArray("breakdowns").objs().map { j ->
        WorkBreakdown(j.getLong("id"), j.getLong("entryId"), j.getString("label"), j.getDouble("quantity"))
    }
    val sessions = o.getJSONArray("sessions").objs().map { j ->
        DailySession(j.getLong("date"), j.lng("startMs"), j.lng("endMs"), j.optInt("breakMin", 0), j.optString("note", ""),
            j.optLong("createdAt", 0), j.optLong("updatedAt", 0))
    }
    val blocks = o.getJSONArray("blocks").objs().map { j ->
        WorkBreak(j.getLong("id"), j.getLong("date"), j.getInt("minutes"), j.getString("type"), j.lng("startMs"),
            j.optString("note", ""), j.optLong("createdAt", 0))
    }
    val catIds = cats.map { it.id }.toSet()
    require(catIds.size == cats.size) { "duplicate work ids" }
    val entryIds = entries.map { it.id }.toSet()
    require(entryIds.size == entries.size) { "duplicate entry ids" }
    require(entries.all { it.categoryId in catIds }) { "an entry refers to a missing work category" }
    require(entries.all { it.quantity.isFinite() && it.quantity >= 0 && (it.durationMin ?: 0) in 0..1440 }) { "an entry has an invalid number" }
    require(bds.all { it.entryId in entryIds && it.quantity.isFinite() }) { "a breakdown refers to a missing entry" }
    require(sessions.map { it.date }.toSet().size == sessions.size) { "duplicate day records" }
    require(blocks.all { it.minutes in 1..1440 }) { "a time block is invalid" }
    return Parsed(cats, entries, bds, sessions, blocks)
}

private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

fun toCsv(d: AppData): String {
    val sb = StringBuilder("date,work,unit,quantity,sets,design,duration_min,start_time,notes,breakdown\n")
    d.entries.sortedWith(compareBy({ it.date }, { it.createdAt })).forEach { e ->
        val c = d.catById[e.categoryId]
        val bd = d.bdByEntry[e.id].orEmpty().joinToString("; ") { it.label + "=" + fmtNum(it.quantity) }
        sb.append(dateOf(e.date)).append(',').append(q(c?.name ?: "")).append(',').append(q(c?.unit ?: "")).append(',')
            .append(fmtNum(e.quantity)).append(',').append(e.sets?.let { fmtNum(it) } ?: "").append(',').append(q(e.design)).append(',')
            .append(e.durationMin ?: "").append(',').append(e.startMs?.let { fmtTime(it, true) } ?: "").append(',')
            .append(q(e.notes)).append(',').append(q(bd)).append('\n')
    }
    return sb.toString()
}

fun toReport(d: AppData, h24: Boolean): String {
    val sb = StringBuilder("EARNSTAR TRACKER - WORK REPORT\n==============================\n\n")
    d.allDates.sortedDescending().forEach { dt ->
        val s = d.day(dt)
        sb.append(fmtDateLong(dt)).append('\n')
        s.elapsed?.let { sb.append("  Elapsed: ${fmtDur(it)}   Break: ${fmtDur(s.knownBreak)}\n") }
        sb.append("  Recorded work: ${fmtDur(s.recorded)}")
        s.unaccounted?.let { sb.append("   Unaccounted: ${fmtDur(it)}") }
        sb.append('\n')
        s.entries.forEach { e ->
            val c = d.catById[e.categoryId]
            sb.append("  - ${c?.name ?: "?"}: ${fmtNum(e.quantity)} ${c?.unit ?: ""}")
            e.sets?.let { sb.append(", ${fmtNum(it)} sets") }
            if (e.design.isNotBlank()) sb.append(", design ${e.design}")
            e.durationMin?.let { sb.append(", ${fmtDur(it)}") }
            e.startMs?.let { sb.append(", at ${fmtTime(it, h24)}") }
            sb.append('\n')
            d.bdByEntry[e.id]?.forEach { sb.append("      ${it.label}: ${fmtNum(it.quantity)}\n") }
            if (e.notes.isNotBlank()) sb.append("      note: ${e.notes}\n")
        }
        s.blocks.forEach { sb.append("  - ${it.type}: ${fmtDur(it.minutes)}\n") }
        s.session?.note?.takeIf { it.isNotBlank() }?.let { sb.append("  Day note: $it\n") }
        sb.append('\n')
    }
    return sb.toString()
}
