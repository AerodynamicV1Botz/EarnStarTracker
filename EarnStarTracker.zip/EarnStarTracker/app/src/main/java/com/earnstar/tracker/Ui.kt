package com.earnstar.tracker

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun App(vm: Vm) {
    val dark = when (vm.prefs.theme) { "DARK" -> true; "LIGHT" -> false; else -> isSystemInDarkTheme() }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF9FA8FF), secondary = Color(0xFFFFCA28))
    else lightColorScheme(primary = Color(0xFF3949AB), secondary = Color(0xFFF9A825))
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize()) {
            val d by vm.data.collectAsState()
            val ctx = LocalContext.current
            val t = vm.toast
            LaunchedEffect(t) { if (t != null) { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show(); vm.toast = null } }
            val dd = d
            if (dd == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else if (dd.cats.isEmpty() && !vm.prefs.setupDone) SetupScreen(vm, dd)
            else Root(vm, dd)
        }
    }
}

@Composable
fun Root(vm: Vm, d: AppData) {
    BackHandler(enabled = vm.screen !is Screen.Home) { vm.back() }
    vm.pending?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.pending = null },
            title = { Text("Restore this backup?") },
            text = { Text("The file is valid: ${p.cats.size} work types, ${p.entries.size} entries, ${p.sessions.size} day records.\n\nRestoring REPLACES the data currently in the app. A safety copy of the current data is saved first.") },
            confirmButton = { TextButton(onClick = { vm.confirmImport() }) { Text("Restore") } },
            dismissButton = { TextButton(onClick = { vm.pending = null }) { Text("Cancel") } }
        )
    }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Home" to Icons.Filled.Home, "Add Work" to Icons.Filled.AddCircle, "History" to Icons.Filled.History,
                "Statistics" to Icons.Filled.BarChart, "Settings" to Icons.Filled.Settings).forEachIndexed { i, (n, ic) ->
                NavigationBarItem(selected = vm.screen.tab == i, onClick = { vm.tab(i) }, icon = { Icon(ic, n) }, label = { Text(n, maxLines = 1, fontSize = 11.sp) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (val s = vm.screen) {
                Screen.Home -> HomeScreen(vm, d)
                is Screen.Add -> key(s) { AddScreen(vm, d, s) }
                Screen.History -> HistoryScreen(vm, d)
                is Screen.Day -> DayScreen(vm, d, s.date)
                Screen.Stats -> StatsScreen(vm, d)
                is Screen.CatDetail -> CatDetailScreen(vm, d, s.id)
                Screen.Settings -> SettingsScreen(vm, d)
                Screen.Cats -> CatsScreen(vm, d)
                is Screen.CatEdit -> key(s) { CatEditScreen(vm, d, s.id) }
            }
        }
    }
}

// ---------- shared building blocks ----------
@Composable
fun ScreenList(content: LazyListScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun Card2(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth()
    if (onClick != null) Card(onClick = onClick, modifier = m, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    } else Card(modifier = m, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}

@Composable
fun RowScope.Tile(label: String, value: String, color: Color = MaterialTheme.colorScheme.primary) {
    Column(Modifier.weight(1f).background(color.copy(alpha = 0.12f), RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun Chips(options: List<String>, selected: String?, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) }) }
    }
}

@Composable
fun Field(v: String, onChange: (String) -> Unit, label: String, num: Boolean = false, modifier: Modifier = Modifier, err: String? = null, single: Boolean = true) {
    Column(modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = v, onValueChange = onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), isError = err != null,
            singleLine = single, keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Decimal else KeyboardType.Text)
        )
        if (err != null) Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text(text, fontSize = 17.sp) }
}

@Composable
fun Confirm(title: String, text: String, ok: String = "Delete", onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onYes) { Text(ok) } },
        dismissButton = { TextButton(onClick = onNo) { Text("Cancel") } }
    )
}

@Composable
fun Bars(data: List<Pair<String, Double>>, unit: String) {
    if (data.isEmpty()) { Text("No data in this period", style = MaterialTheme.typography.bodySmall); return }
    val mx = (data.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(0.0001)
    val c = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().height(110.dp), verticalAlignment = Alignment.Bottom) {
        data.forEach { (_, v) ->
            Box(Modifier.weight(1f).padding(horizontal = 1.dp).fillMaxHeight((v / mx).toFloat().coerceIn(0.02f, 1f))
                .background(if (v <= 0) Color.Transparent else c, RoundedCornerShape(3.dp)))
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(data.first().first, style = MaterialTheme.typography.labelSmall)
        Text("max ${fmtNum(mx)} $unit", style = MaterialTheme.typography.labelSmall)
        Text(data.last().first, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun HBar(label: String, value: String, frac: Float, color: Color = MaterialTheme.colorScheme.primary) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row { Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold) }
        Box(Modifier.fillMaxWidth().height(10.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(5.dp))) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, RoundedCornerShape(5.dp)))
        }
    }
}

// ---------- first-time setup + category form ----------
@Composable
fun SetupScreen(vm: Vm, d: AppData) {
    ScreenList {
        item { Text("Welcome", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Create the types of work you do, once. You can add, edit, reorder or archive them later in Settings.") }
        if (d.cats.isNotEmpty()) item {
            Card2 { Text("Created so far", fontWeight = FontWeight.Bold); d.cats.forEach { Text("• ${it.name} (${it.unit})") } }
        }
        item { key(d.cats.size) { CatForm(vm, d, null, "Add work") {} } }
        item { BigButton("Start using the app", enabled = d.cats.isNotEmpty()) { vm.prefs.putSetupDone(true) } }
        item { TextButton(onClick = { vm.prefs.putSetupDone(true) }, modifier = Modifier.fillMaxWidth()) { Text("Skip for now") } }
    }
}

@Composable
fun CatForm(vm: Vm, d: AppData, existing: WorkCategory?, saveLabel: String, onSaved: () -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var unit by remember { mutableStateOf(existing?.unit ?: vm.prefs.defaultUnit) }
    var dt by remember { mutableStateOf(existing?.dailyTarget?.let(::fmtNum) ?: "") }
    var wt by remember { mutableStateOf(existing?.weeklyTarget?.let(::fmtNum) ?: "") }
    var mt by remember { mutableStateOf(existing?.monthlyTarget?.let(::fmtNum) ?: "") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    fun tgt(s: String): Double? = s.replace(',', '.').toDoubleOrNull()
    val dup = d.cats.any { it.name.trim().equals(name.trim(), true) && it.id != (existing?.id ?: -1L) }
    val badT = listOf(dt, wt, mt).any { it.isNotBlank() && ((tgt(it) ?: -1.0) <= 0) }
    val ok = name.isNotBlank() && unit.isNotBlank() && !dup && !badT
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Field(name, { name = it }, "Work name (e.g. Sewing)", err = if (dup) "A work with this name already exists" else null)
        Field(unit, { unit = it }, "Unit (e.g. Dozen)")
        Chips(listOf("Dozen", "Pieces", "Sets", "Kg", "Meter", "Boxes"), unit) { unit = it }
        Field(dt, { dt = it }, "Daily target (optional)", num = true)
        Field(wt, { wt = it }, "Weekly target (optional)", num = true)
        Field(mt, { mt = it }, "Monthly target (optional)", num = true)
        if (badT) Text("Targets must be numbers greater than 0", color = MaterialTheme.colorScheme.error)
        Field(desc, { desc = it }, "Description (optional)")
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Active", Modifier.weight(1f)); Switch(checked = active, onCheckedChange = { active = it }) }
        BigButton(saveLabel, enabled = ok) {
            val c = (existing ?: WorkCategory(name = "", unit = "")).copy(
                name = name.trim(), unit = unit.trim(), dailyTarget = tgt(dt), weeklyTarget = tgt(wt), monthlyTarget = tgt(mt),
                description = desc.trim(), active = active)
            vm.saveCategory(c) { onSaved() }
        }
    }
}
