package com.earnstar.tracker

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.max

// ---------- time helpers ----------
val zone: ZoneId get() = ZoneId.systemDefault()
fun today(): Long = LocalDate.now().toEpochDay()
fun dateOf(d: Long): LocalDate = LocalDate.ofEpochDay(d)
fun fmtDate(d: Long): String = dateOf(d).format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH))
fun fmtDateLong(d: Long): String = dateOf(d).format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy", Locale.ENGLISH))
fun fmtTime(ms: Long, h24: Boolean): String =
    Instant.ofEpochMilli(ms).atZone(zone).format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "hh:mm a", Locale.ENGLISH))
fun fmtTod(tod: Int, h24: Boolean): String =
    LocalTime.of(tod / 60, tod % 60).format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "hh:mm a", Locale.ENGLISH))
fun todOf(ms: Long): Int { val z = Instant.ofEpochMilli(ms).atZone(zone); return z.hour * 60 + z.minute }
fun fmtDur(min: Int): String { val h = min / 60; val m = min % 60; return if (h > 0 && m > 0) "${h}h ${m}m" else if (h > 0) "${h}h" else "${m}m" }
fun fmtNum(v: Double): String = if (v == Math.rint(v)) v.toLong().toString() else String.format(Locale.ENGLISH, "%.2f", v).trimEnd('0').trimEnd('.')
fun msOf(date: Long, tod: Int): Long = dateOf(date).atTime(tod / 60, tod % 60).atZone(zone).toInstant().toEpochMilli()
/** Elapsed minutes between two instants; an end before the start means the session crossed midnight. */
fun elapsedMin(s: Long, e: Long): Int { var d = e - s; if (d <= 0) d += 86_400_000L; return (d / 60_000).toInt() }

/** ONE source of truth for real output: base quantity x multiplier, only when the work defines a multiplier. */
fun WorkEntry.totalFor(c: WorkCategory?): Double {
    val m = sets
    return if (c?.multiplierLabel != null && m != null && m > 0) quantity * m else quantity
}

/** Live timer display, h:mm:ss. */
fun fmtHms(ms: Long): String {
    val s = ms.coerceAtLeast(0L) / 1000L
    return String.format(Locale.ENGLISH, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

fun pickDate(c: Context, cur: Long, onPick: (Long) -> Unit) {
    val d = dateOf(cur)
    DatePickerDialog(c, { _, y, m, day -> onPick(LocalDate.of(y, m + 1, day).toEpochDay()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
}
fun pickTime(c: Context, h24: Boolean, tod: Int?, onPick: (Int) -> Unit) {
    val t = tod ?: (LocalTime.now().hour * 60 + LocalTime.now().minute)
    TimePickerDialog(c, { _, h, m -> onPick(h * 60 + m) }, t / 60, t % 60, h24).show()
}

// ---------- statistics ----------
class DayStat(
    val date: Long, val session: DailySession?, val entries: List<WorkEntry>, val blocks: List<WorkBreak>,
    val elapsed: Int?, val knownBreak: Int, val otherMin: Int, val recorded: Int, val unaccounted: Int?, val over: Boolean,
    val qtyByCat: Map<Long, Double>
) {
    val available: Int? get() = elapsed?.let { max(0, it - knownBreak) }
    val productivity: Int? get() { val a = available; return if (a != null && a > 0) minOf(100, recorded * 100 / a) else null }
}

class CatStat(val cat: WorkCategory, val entries: List<WorkEntry>) {
    val dayQty: Map<Long, Double> = entries.groupBy { it.date }.mapValues { e -> e.value.sumOf { it.totalFor(cat) } }
    val days = dayQty.size
    /** Sum of base quantities as typed (before the multiplier). */
    val baseQty = entries.sumOf { it.quantity }
    /** Calculated total (base x multiplier where configured). */
    val qty = entries.sumOf { it.totalFor(cat) }
    val sets = entries.sumOf { it.sets ?: 0.0 }
    val recMin = entries.sumOf { it.durationMin ?: 0 }
    private val timed = entries.filter { (it.durationMin ?: 0) > 0 }
    val perHour: Double? = run {
        val m = timed.sumOf { it.durationMin ?: 0 }
        if (m > 0) timed.sumOf { it.totalFor(cat) } / (m / 60.0) else null
    }
    val perDay: Double = if (days > 0) qty / days else 0.0
    val best = dayQty.maxByOrNull { it.value }
    val worst = dayQty.minByOrNull { it.value }
    val byDesign: List<Pair<String, Double>> = entries.filter { it.design.isNotBlank() }
        .groupBy { it.design.trim() }.map { (k, v) -> k to v.sumOf { it.totalFor(cat) } }.sortedByDescending { it.second }
}

class Agg(val days: Int, val elapsed: Int, val rec: Int, val unacc: Int, val brk: Int, val other: Int, val bestDay: Pair<Long, Double>?)

class AppData(
    val cats: List<WorkCategory>, val entries: List<WorkEntry>, val breakdowns: List<WorkBreakdown>,
    val sessions: List<DailySession>, val blocks: List<WorkBreak>
) {
    val catById = cats.associateBy { it.id }
    val entriesByDate = entries.groupBy { it.date }
    val sessionByDate = sessions.associateBy { it.date }
    val blocksByDate = blocks.groupBy { it.date }
    val bdByEntry = breakdowns.groupBy { it.entryId }
    val allDates: List<Long> = (entriesByDate.keys + sessionByDate.keys + blocksByDate.keys).sortedDescending()

    fun day(d: Long): DayStat {
        val es = entriesByDate[d].orEmpty()
        val s = sessionByDate[d]
        val bs = blocksByDate[d].orEmpty()
        val st = s?.startMs
        val en = s?.endMs
        val elapsed = if (st != null && en != null) elapsedMin(st, en) else null
        val rec = es.sumOf { it.durationMin ?: 0 }
        val kb = (s?.breakMin ?: 0) + bs.filter { it.type == "Break" }.sumOf { it.minutes }
        val oc = bs.filter { it.type != "Break" }.sumOf { it.minutes }
        val un = elapsed?.let { max(0, it - kb - oc - rec) }   // never negative
        val over = elapsed != null && rec + kb + oc > elapsed
        val qty = es.groupBy { it.categoryId }.mapValues { g -> g.value.sumOf { it.totalFor(catById[g.key]) } }
        return DayStat(d, s, es, bs, elapsed, kb, oc, rec, un, over, qty)
    }

    fun cat(c: WorkCategory, f: Long, t: Long) = CatStat(c, entries.filter { it.categoryId == c.id && it.date in f..t })

    fun agg(f: Long, t: Long): Agg {
        var el = 0; var rec = 0; var un = 0; var br = 0; var ot = 0
        var best: Pair<Long, Double>? = null
        val ds = allDates.filter { it in f..t }
        for (x in ds) {
            val s = day(x)
            el += s.elapsed ?: 0; rec += s.recorded; un += s.unaccounted ?: 0; br += s.knownBreak; ot += s.otherMin
            val a = s.available
            if (a != null && a > 0) {
                val r = s.recorded.toDouble() / a
                val b = best
                if (b == null || r > b.second) best = x to r
            }
        }
        return Agg(ds.size, el, rec, un, br, ot, best)
    }

    fun trend(c: WorkCategory): String {
        val t = today()
        val a = cat(c, t - 6, t); val b = cat(c, t - 13, t - 7)
        if (a.days == 0 || b.days == 0 || b.perDay == 0.0) return "Not enough data yet"
        val r = a.perDay / b.perDay
        return if (r > 1.05) "Improving" else if (r < 0.95) "Declining" else "Stable"
    }

    fun targetFor(c: WorkCategory, p: String): Double? = when (p) { "Day" -> c.dailyTarget; "Week" -> c.weeklyTarget; else -> c.monthlyTarget }

    fun actualFor(c: WorkCategory, p: String, ref: Long): Double {
        val td = dateOf(ref)
        val (f, t) = when (p) {
            "Day" -> ref to ref
            "Week" -> td.with(DayOfWeek.MONDAY).toEpochDay() to td.with(DayOfWeek.SUNDAY).toEpochDay()
            else -> td.withDayOfMonth(1).toEpochDay() to td.withDayOfMonth(td.lengthOfMonth()).toEpochDay()
        }
        return entries.filter { it.categoryId == c.id && it.date in f..t }.sumOf { it.totalFor(c) }
    }

    /** 0 = nothing, 1 = work recorded, 2 = partial target, 3 = all targets reached. */
    fun dayState(d: Long): Int {
        val es = entriesByDate[d].orEmpty()
        if (es.isEmpty()) return 0
        val targeted = cats.filter { it.active && (it.dailyTarget ?: 0.0) > 0 }
        if (targeted.isEmpty()) return 1
        val q = es.groupBy { it.categoryId }.mapValues { e -> e.value.sumOf { it.totalFor(catById[e.key]) } }
        val hit = targeted.count { (q[it.id] ?: 0.0) >= (it.dailyTarget ?: Double.MAX_VALUE) }
        val any = targeted.any { (q[it.id] ?: 0.0) > 0 }
        return if (hit == targeted.size) 3 else if (any) 2 else 1
    }

    fun series(c: WorkCategory, f: Long, t: Long, g: String): List<Pair<String, Double>> {
        val es = entries.filter { it.categoryId == c.id && it.date in f..t }
        if (g == "Daily") {
            val from = max(f, t - 30)
            return (from..t).map { day -> dateOf(day).dayOfMonth.toString() to es.filter { it.date == day }.sumOf { it.totalFor(c) } }
        }
        val fm = DateTimeFormatter.ofPattern(if (g == "Weekly") "d MMM" else "MMM yy", Locale.ENGLISH)
        return es.groupBy { e ->
            val dt = dateOf(e.date)
            if (g == "Weekly") dt.with(DayOfWeek.MONDAY) else dt.withDayOfMonth(1)
        }.toSortedMap(compareBy<LocalDate> { it.toEpochDay() }).map { (k, v) -> k.format(fm) to v.sumOf { it.totalFor(c) } }
    }
}

fun overlapWith(e: WorkEntry, others: List<WorkEntry>): WorkEntry? {
    val s = e.startMs ?: return null
    val d = e.durationMin ?: return null
    if (d <= 0) return null
    val en = s + d * 60_000L
    return others.firstOrNull { o ->
        val os = o.startMs ?: return@firstOrNull false
        val od = o.durationMin ?: return@firstOrNull false
        o.id != e.id && od > 0 && s < os + od * 60_000L && os < en
    }
}

val RANGES = listOf("Today", "Yesterday", "7 days", "This week", "30 days", "This month", "Last month", "This year", "All time", "Custom")

fun rangeOf(name: String, d: AppData, cf: Long, ct: Long): Pair<Long, Long> {
    val t = today(); val td = dateOf(t)
    return when (name) {
        "Today" -> t to t
        "Yesterday" -> (t - 1) to (t - 1)
        "7 days" -> (t - 6) to t
        "This week" -> td.with(DayOfWeek.MONDAY).toEpochDay() to t
        "30 days" -> (t - 29) to t
        "This month" -> td.withDayOfMonth(1).toEpochDay() to t
        "Last month" -> { val f = td.withDayOfMonth(1).minusMonths(1); f.toEpochDay() to f.withDayOfMonth(f.lengthOfMonth()).toEpochDay() }
        "This year" -> td.withDayOfYear(1).toEpochDay() to t
        "All time" -> (d.allDates.lastOrNull() ?: t) to t
        else -> minOf(cf, ct) to maxOf(cf, ct)
    }
}

fun monthName(d: Long): String = dateOf(d).month.getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + dateOf(d).year
