package com.earnstar.tracker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalTime
import kotlinx.coroutines.delay
import kotlin.math.abs

/** Stops the running timer and opens the entry form pre-filled with the measured time. */
fun stopAndRecord(vm: Vm, now: Long) {
    val cat = vm.prefs.timerCat
    val start = vm.prefs.timerStart
    if (cat == -1L || start == 0L) return
    val mins = ((now - start) / 60_000L).toInt().coerceIn(0, 1440)
    vm.stopTimer()
    vm.go(Screen.Add(date = today(), cat = cat, prefillDur = mins, prefillStart = start))
}

// ================= HOME =================
@Composable
fun HomeScreen(vm: Vm, d: AppData) {
    val t = today()
    val s = d.day(t)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var askSwitch by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(vm.prefs.timerCat) {
        while (true) { now = System.currentTimeMillis(); delay(1000L) }
    }
    val hr = LocalTime.now().hour
    val greet = if (hr < 12) "Good morning" else if (hr < 17) "Good afternoon" else "Good evening"
    ScreenList {
        item {
            Text(vm.prefs.appName, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(greet, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(fmtDateLong(t))
        }
        item {
            Card2 {
                Text("Today's Progress", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Work Time", s.elapsed?.let { fmtDur(it) } ?: "—")
                    Tile("Recorded", fmtDur(s.recorded), Color(0xFF2E7D32))
                    Tile("Unaccounted", s.unaccounted?.let { fmtDur(it) } ?: "—", Color(0xFFEF6C00))
                }
                Text("${s.entries.size} entries today" + (s.productivity?.let { " • $it% of available time recorded" } ?: ""))
                if (s.elapsed == null) Text("Tap Start Day / End Day to track elapsed time.", style = MaterialTheme.typography.bodySmall)
                else Text("Break ${fmtDur(s.knownBreak)} • Available ${fmtDur(s.available ?: 0)}", style = MaterialTheme.typography.bodySmall)
                if (s.over) Text("Recorded work + breaks are more than the elapsed time. Please check your entries.", color = MaterialTheme.colorScheme.error)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("+ Add Work") { vm.go(Screen.Add()) }
                OutlinedButton(onClick = { vm.go(Screen.CatEdit(null)) }, Modifier.fillMaxWidth()) { Text("+ New Work") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.startDay() }, Modifier.weight(1f)) { Text("Start Day") }
                    OutlinedButton(onClick = { vm.endDay() }, Modifier.weight(1f)) { Text("End Day") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.go(Screen.Day(t)) }, Modifier.weight(1f)) { Text("View Today") }
                    OutlinedButton(onClick = { vm.go(Screen.Settings) }, Modifier.weight(1f)) { Text("Backup") }
                }
            }
        }
        // ---- timer ----
        if (vm.prefs.timerCat != -1L && d.catById[vm.prefs.timerCat] != null) item {
            val rc = d.catById[vm.prefs.timerCat]!!
            Card2 {
                Text("RUNNING", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(rc.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(fmtHms(now - vm.prefs.timerStart), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                BigButton("STOP & RECORD") { stopAndRecord(vm, System.currentTimeMillis()) }
            }
        }
        val startable = d.cats.filter { it.active }
        if (startable.isNotEmpty()) item { Text("Start a timer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(startable, key = { "tm${it.id}" }) { c ->
            OutlinedButton(onClick = {
                if (vm.prefs.timerCat == -1L) vm.startTimer(c.id)
                else if (vm.prefs.timerCat == c.id) vm.toast = "${c.name} is already running"
                else askSwitch = c.id
            }, Modifier.fillMaxWidth()) { Text("Start ${c.name}") }
        }
        if (askSwitch != null) item {
            val running = d.catById[vm.prefs.timerCat]
            AlertDialog(
                onDismissRequest = { askSwitch = null },
                title = { Text("${running?.name ?: "A work"} is currently running.") },
                text = { Text("Only one timer runs at a time, so stop it and save its time first. Then start the new work.") },
                confirmButton = { TextButton(onClick = { askSwitch = null; stopAndRecord(vm, System.currentTimeMillis()) }) { Text("Stop ${running?.name ?: "it"}") } },
                dismissButton = { TextButton(onClick = { askSwitch = null }) { Text("Cancel") } }
            )
        }

        item { Text("Today's Work", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (s.entries.isEmpty()) item {
            Card2 {
                Text("No work recorded today.", fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { vm.go(Screen.Add()) }) { Text("Add Work") }
            }
        }
        d.cats.filter { s.qtyByCat.containsKey(it.id) }.forEach { c ->
            item(key = "wc${c.id}") { WorkCard(vm, d, c, s) }
        }
        item { SummaryCard(d, s) }
    }
}

@Composable
fun WorkCard(vm: Vm, d: AppData, c: WorkCategory, s: DayStat) {
    val es = s.entries.filter { it.categoryId == c.id }
    val base = es.sumOf { it.quantity }
    val qty = es.sumOf { it.totalFor(c) }
    val sets = es.sumOf { it.sets ?: 0.0 }
    val designs = es.map { it.design }.filter { it.isNotBlank() }.distinct()
    val rec = es.sumOf { it.durationMin ?: 0 }
    val unitTxt = c.unit.lowercase()
    val multLbl = c.multiplierLabel
    Card2(onClick = { vm.go(Screen.Day(s.date)) }) {
        Text(c.name.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text("${fmtNum(qty)} $unitTxt", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (multLbl != null && sets > 0) Text("${fmtNum(base)} $unitTxt x ${fmtNum(sets)} $multLbl = ${fmtNum(qty)} $unitTxt", style = MaterialTheme.typography.bodySmall)
        else if (sets > 0) Text("${fmtNum(sets)} sets")
        if (designs.isNotEmpty()) Text("Design: ${designs.joinToString(", ")}")
        es.forEach { e -> d.bdByEntry[e.id]?.let { l -> if (l.isNotEmpty()) Text(l.joinToString(" + ") { "${it.label} ${fmtNum(it.quantity)}" }) } }
        if (rec > 0) Text("Recorded work time: ${fmtDur(rec)}")
        c.dailyTarget?.takeIf { it > 0 }?.let { tg ->
            val pct = (qty / tg * 100).toInt()
            LinearProgressIndicator(progress = { (qty / tg).toFloat().coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
            Text("Target ${fmtNum(qty)} / ${fmtNum(tg)} $unitTxt - $pct%", style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Plain summary computed only from stored data. */
@Composable
fun SummaryCard(d: AppData, s: DayStat) {
    Card2 {
        Text("Daily Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Work time: ${s.elapsed?.let { fmtDur(it) } ?: "not set"}")
        Text("Recorded work: ${fmtDur(s.recorded)}")
        s.unaccounted?.let { Text("Unaccounted: ${fmtDur(it)}") }
        if (s.knownBreak > 0) Text("Break: ${fmtDur(s.knownBreak)}")
        d.cats.forEach { c ->
            val q = s.qtyByCat[c.id] ?: return@forEach
            Text("${c.name}: ${fmtNum(q)} ${c.unit.lowercase()}")
        }
        d.cats.forEach { c ->
            val q = s.qtyByCat[c.id] ?: return@forEach
            val tg = c.dailyTarget ?: return@forEach
            if (tg > 0) Text("${c.name} target: ${fmtNum(q)} / ${fmtNum(tg)} (${(q / tg * 100).toInt()}%)")
        }
        s.session?.note?.takeIf { it.isNotBlank() }?.let { Text("Note: $it") }
    }
}

// ================= ADD / EDIT ENTRY =================
@Composable
fun AddScreen(vm: Vm, d: AppData, sc: Screen.Add) {
    val ctx = LocalContext.current
    val h24 = vm.prefs.hour24
    val editing = sc.editId?.let { id -> d.entries.firstOrNull { it.id == id } }
    val active = d.cats.filter { it.active || it.id == editing?.categoryId }
    var date by remember { mutableStateOf(editing?.date ?: sc.date) }
    var catId by remember { mutableStateOf<Long?>(editing?.categoryId ?: sc.cat ?: vm.prefs.defaultCat.takeIf { id -> active.any { it.id == id } } ?: active.firstOrNull()?.id) }
    var qty by remember { mutableStateOf(editing?.quantity?.let { fmtNum(it) } ?: "") }
    var sets by remember { mutableStateOf(editing?.sets?.let { fmtNum(it) } ?: "") }
    var design by remember { mutableStateOf(editing?.design ?: "") }
    var dur by remember { mutableStateOf(editing?.durationMin?.toString() ?: sc.prefillDur?.toString() ?: "") }
    var tod by remember { mutableStateOf<Int?>(editing?.startMs?.let { todOf(it) } ?: sc.prefillStart?.let { todOf(it) }) }
    var notes by remember { mutableStateOf(editing?.notes ?: "") }
    val bd: SnapshotStateList<Pair<String, String>> = remember {
        mutableStateListOf<Pair<String, String>>().also { l -> editing?.let { e -> d.bdByEntry[e.id]?.forEach { l.add(it.label to fmtNum(it.quantity)) } } }
    }
    var warn by remember { mutableStateOf<String?>(null) }
    var askDelete by remember { mutableStateOf(false) }

    val cat = d.catById[catId]
    val multLbl = cat?.multiplierLabel
    val q = qty.replace(',', '.').toDoubleOrNull()
    val bdVals = bd.filter { it.first.isNotBlank() || it.second.isNotBlank() }
    val bdSum = bdVals.sumOf { it.second.replace(',', '.').toDoubleOrNull() ?: 0.0 }
    val bdBad = bdVals.any { it.first.isBlank() || ((it.second.replace(',', '.').toDoubleOrNull() ?: -1.0) <= 0) }
    val mismatch = bdVals.isNotEmpty() && q != null && abs(bdSum - q) > 0.0001
    val durV = if (dur.isBlank()) null else dur.toIntOrNull()
    val durBad = dur.isNotBlank() && (durV == null || durV < 0 || durV > 1440)
    val setsBad = sets.isNotBlank() && sets.replace(',', '.').toDoubleOrNull() == null
    val ok = catId != null && q != null && q > 0 && !bdBad && !mismatch && !durBad && !setsBad

    fun build(): WorkEntry {
        var sm = tod?.let { msOf(date, it) }
        val sst = d.sessionByDate[date]?.startMs
        if (sm != null && sst != null && sm < sst) sm += 86_400_000L   // after midnight in an overnight session
        return WorkEntry(id = editing?.id ?: 0, date = date, categoryId = catId!!, quantity = q!!, sets = sets.replace(',', '.').toDoubleOrNull(),
            design = design.trim(), durationMin = durV, startMs = sm, notes = notes.trim(), createdAt = editing?.createdAt ?: System.currentTimeMillis())
    }
    fun doSave() {
        val e = build()
        vm.saveEntry(e, bdVals.map { it.first.trim() to (it.second.replace(',', '.').toDouble()) }) {
            if (editing != null) vm.back() else { vm.toast = "Entry saved"; vm.tab(0) }
        }
    }
    fun checkAndSave() {
        val e = build()
        val w = mutableListOf<String>()
        overlapWith(e, d.entriesByDate[date].orEmpty())?.let { o -> w.add("This overlaps with another entry (${d.catById[o.categoryId]?.name ?: "work"}) at the same time.") }
        val st = d.day(date)
        val el = st.elapsed
        if (el != null) {
            val newRec = st.recorded - (editing?.durationMin ?: 0) + (durV ?: 0)
            if (newRec + st.knownBreak + st.otherMin > el) w.add("Recorded work would be more than the elapsed time for this day.")
        }
        if (w.isEmpty()) doSave() else warn = w.joinToString("\n\n")
    }

    ScreenList {
        item { Header(if (editing != null) "Edit Work" else "Add Work", onBack = if (editing != null) ({ vm.back() }) else null) }
        if (active.isEmpty()) {
            item { Text("No works yet. Create your first work to start tracking.") }
            item { BigButton("+ New Work") { vm.go(Screen.CatEdit(null)) } }
            return@ScreenList
        }
        item { OutlinedButton(onClick = { vm.go(Screen.CatEdit(null)) }, Modifier.fillMaxWidth()) { Text("+ New Work") } }
        item { OutlinedButton(onClick = { pickDate(ctx, date) { date = it } }, Modifier.fillMaxWidth()) { Text("Date: ${fmtDate(date)}") } }
        item { Chips(active.map { it.name }, cat?.name) { n -> catId = active.firstOrNull { it.name == n }?.id } }
        item {
            Field(qty, { qty = it }, "Quantity" + (cat?.let { " (${it.unit})" } ?: ""), num = true,
                err = if (qty.isNotBlank() && (q == null || q <= 0)) "Enter a number greater than 0" else null)
        }
        if (multLbl != null) item {
            Field(sets, { sets = it }, "$multLbl (multiplier, optional)", num = true, err = if (setsBad) "Not a number" else null)
        }
        item {
            val mv = sets.replace(',', '.').toDoubleOrNull()
            val unitTxt = cat?.unit?.lowercase() ?: ""
            if (q != null && q > 0) Text(
                if (multLbl != null && mv != null && mv > 0) "Calculated total: ${fmtNum(q)} x ${fmtNum(mv)} $multLbl = ${fmtNum(q * mv)} $unitTxt"
                else "Total: ${fmtNum(q)} $unitTxt",
                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Field(dur, { dur = it }, "Time spent (minutes)", num = true, err = if (durBad) "0 to 1440" else null)
        }
        item { Field(design, { design = it }, "Design / print name (optional)") }
        val recent = d.entries.filter { it.categoryId == catId && it.design.isNotBlank() }.sortedByDescending { it.createdAt }.map { it.design }.distinct().take(8)
        if (recent.isNotEmpty()) item { Chips(recent, design) { design = it } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickTime(ctx, h24, tod) { tod = it } }, Modifier.weight(1f)) { Text(tod?.let { "Started: ${fmtTod(it, h24)}" } ?: "Start time (optional)") }
                if (tod != null) TextButton(onClick = { tod = null }) { Text("Clear") }
            }
        }
        item {
            Card2 {
                Text("Breakdown (optional)", fontWeight = FontWeight.Bold)
                Text("Split the total by print/design. The parts must add up to the total quantity.", style = MaterialTheme.typography.bodySmall)
                bd.forEachIndexed { i, p ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Field(p.first, { bd[i] = bd[i].copy(first = it) }, "Print / design", modifier = Modifier.weight(1.4f))
                        Field(p.second, { bd[i] = bd[i].copy(second = it) }, "Qty", num = true, modifier = Modifier.weight(1f))
                        IconButton(onClick = { bd.removeAt(i) }) { Icon(Icons.Filled.Delete, "Remove") }
                    }
                }
                TextButton(onClick = { bd.add("" to "") }) { Text("+ Add breakdown line") }
                if (bdVals.isNotEmpty()) {
                    Text("Breakdown total: ${fmtNum(bdSum)}" + (cat?.let { " ${it.unit.lowercase()}" } ?: ""), fontWeight = FontWeight.Bold)
                    if (mismatch) {
                        Text("Breakdown (${fmtNum(bdSum)}) does not equal the total (${fmtNum(q ?: 0.0)}).", color = MaterialTheme.colorScheme.error)
                        TextButton(onClick = { qty = fmtNum(bdSum) }) { Text("Use breakdown total as quantity") }
                    }
                    if (bdBad) Text("Every line needs a name and a quantity above 0.", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        item { Field(notes, { notes = it }, "Notes (optional)", single = false) }
        item { BigButton(if (editing != null) "Save Changes" else "Save Entry", enabled = ok) { checkAndSave() } }
        if (editing != null) item { OutlinedButton(onClick = { askDelete = true }, Modifier.fillMaxWidth()) { Text("Delete this entry") } }
    }
    warn?.let { w ->
        AlertDialog(
            onDismissRequest = { warn = null }, title = { Text("Please check") }, text = { Text(w) },
            confirmButton = { TextButton(onClick = { warn = null; doSave() }) { Text("Save anyway") } },
            dismissButton = { TextButton(onClick = { warn = null }) { Text("Go back and fix") } }
        )
    }
    if (askDelete && editing != null) Confirm("Delete entry?", "This entry and its breakdown will be permanently deleted.", onYes = { askDelete = false; vm.deleteEntry(editing.id); vm.back() }, onNo = { askDelete = false })
}

// ================= DAY / TIMELINE =================
private class TItem(val key: Long, val time: Long?, val kind: Int, val entry: WorkEntry? = null, val block: WorkBreak? = null)

@Composable
fun DayScreen(vm: Vm, d: AppData, date: Long) {
    val ctx = LocalContext.current
    val h24 = vm.prefs.hour24
    val s = d.day(date)
    val sess = s.session
    var showSession by remember { mutableStateOf(false) }
    var showBlock by remember { mutableStateOf(false) }
    var delEntry by remember { mutableStateOf<WorkEntry?>(null) }
    var delBlock by remember { mutableStateOf<WorkBreak?>(null) }
    var note by remember(date, sess?.note) { mutableStateOf(sess?.note ?: "") }

    val tl = mutableListOf<TItem>()
    sess?.startMs?.let { tl.add(TItem(Long.MIN_VALUE, it, 0)) }
    sess?.endMs?.let { tl.add(TItem(Long.MAX_VALUE, it, 3)) }
    s.entries.forEach { tl.add(TItem(it.startMs ?: (4_000_000_000_000_000_000L + it.createdAt), it.startMs, 1, entry = it)) }
    s.blocks.forEach { tl.add(TItem(it.startMs ?: (4_000_000_000_000_000_000L + it.createdAt), it.startMs, 2, block = it)) }
    tl.sortBy { it.key }

    ScreenList {
        item {
            Header(fmtDate(date), onBack = { vm.back() }) {
                IconButton(onClick = { vm.replaceDay(date - 1) }) { Icon(Icons.Filled.KeyboardArrowLeft, "Previous day") }
                IconButton(onClick = { vm.replaceDay(date + 1) }) { Icon(Icons.Filled.KeyboardArrowRight, "Next day") }
            }
            Text(fmtDateLong(date), style = MaterialTheme.typography.bodySmall)
        }
        item {
            Card2 {
                Text("Day", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Elapsed", s.elapsed?.let { fmtDur(it) } ?: "—")
                    Tile("Recorded", fmtDur(s.recorded), Color(0xFF2E7D32))
                    Tile("Unaccounted", s.unaccounted?.let { fmtDur(it) } ?: "—", Color(0xFFEF6C00))
                }
                Text("Break time: ${fmtDur(s.knownBreak)}" + (if (s.otherMin > 0) " • Other classified: ${fmtDur(s.otherMin)}" else ""))
                s.available?.let { Text("Available work time: ${fmtDur(it)}") }
                if (s.over) Text("Recorded work + breaks exceed the elapsed time. Check the entries or the start/end time.", color = MaterialTheme.colorScheme.error)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showSession = true }, Modifier.weight(1f)) { Text("Start / End / Break") }
                    OutlinedButton(onClick = { showBlock = true }, Modifier.weight(1f)) { Text("Classify time") }
                }
            }
        }
        item { BigButton("+ Add work for this day") { vm.go(Screen.Add(date = date)) } }
        item { Text("Timeline", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (tl.isEmpty()) item { Text("Nothing recorded for this day yet.") }
        items(tl) { it0 ->
            Card2 {
                Row(verticalAlignment = Alignment.Top) {
                    Text(it0.time?.let { t -> fmtTime(t, h24) } ?: "—", Modifier.width(78.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f)) {
                        when (it0.kind) {
                            0 -> Text("Work Started", fontWeight = FontWeight.Bold)
                            3 -> Text("Work Finished", fontWeight = FontWeight.Bold)
                            2 -> { val b = it0.block!!; Text("${b.type} • ${fmtDur(b.minutes)}", fontWeight = FontWeight.Bold); if (b.note.isNotBlank()) Text(b.note) }
                            else -> {
                                val e = it0.entry!!; val c = d.catById[e.categoryId]
                                Text("${c?.name ?: "?"} • ${fmtNum(e.totalFor(c))} ${c?.unit?.lowercase() ?: ""}", fontWeight = FontWeight.Bold)
                                val lbl = c?.multiplierLabel
                                if (lbl != null && e.sets != null) Text("${fmtNum(e.quantity)} x ${fmtNum(e.sets!!)} $lbl = ${fmtNum(e.totalFor(c))} ${c?.unit?.lowercase() ?: ""}", style = MaterialTheme.typography.bodySmall)
                                if (e.design.isNotBlank()) Text("Design: ${e.design}")
                                d.bdByEntry[e.id]?.takeIf { it.isNotEmpty() }?.let { l -> Text(l.joinToString(" + ") { "${it.label} ${fmtNum(it.quantity)}" }) }
                                e.durationMin?.let { Text("Time: ${fmtDur(it)}" + (c?.let { cc -> if (it > 0) " • ${fmtNum(e.totalFor(c) / (it / 60.0))} ${cc.unit.lowercase()}/hr" else "" } ?: "")) }
                                if (e.notes.isNotBlank()) Text(e.notes, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (it0.kind == 1) {
                        IconButton(onClick = { vm.go(Screen.Add(editId = it0.entry!!.id)) }) { Icon(Icons.Filled.Edit, "Edit") }
                        IconButton(onClick = { delEntry = it0.entry }) { Icon(Icons.Filled.Delete, "Delete") }
                    }
                    if (it0.kind == 2) IconButton(onClick = { delBlock = it0.block }) { Icon(Icons.Filled.Delete, "Delete") }
                }
            }
        }
        item { SummaryCard(d, s) }
        item {
            Card2 {
                Text("Daily note", fontWeight = FontWeight.Bold)
                Field(note, { note = it }, "e.g. Slower than usual, material arrived late", single = false)
                Button(onClick = { vm.saveNote(date, note); vm.toast = "Note saved" }, enabled = note.trim() != (sess?.note ?: "")) { Text("Save note") }
            }
        }
    }

    if (showSession) SessionDialog(vm, date, sess, s, ctx) { showSession = false }
    if (showBlock) BlockDialog(vm, date, s, ctx) { showBlock = false }
    delEntry?.let { e -> Confirm("Delete entry?", "This work entry will be permanently deleted.", onYes = { vm.deleteEntry(e.id); delEntry = null }, onNo = { delEntry = null }) }
    delBlock?.let { b -> Confirm("Delete this time block?", "It will count as unaccounted time again.", onYes = { vm.deleteBlock(b.id); delBlock = null }, onNo = { delBlock = null }) }
}

@Composable
private fun SessionDialog(vm: Vm, date: Long, sess: DailySession?, s: DayStat, ctx: android.content.Context, onClose: () -> Unit) {
    val h24 = vm.prefs.hour24
    var st by remember { mutableStateOf<Int?>(sess?.startMs?.let { todOf(it) }) }
    var en by remember { mutableStateOf<Int?>(sess?.endMs?.let { todOf(it) }) }
    var brk by remember { mutableStateOf((sess?.breakMin ?: 0).toString()) }
    val b = brk.toIntOrNull()
    var err: String? = null
    if (b == null || b < 0) err = "Break must be 0 or more minutes"
    if (en != null && st == null) err = "Enter the start time too"
    if (st != null && en != null && st == en) err = "Start and end time cannot be the same"
    if (err == null && st != null && en != null && b != null) {
        val sm = msOf(date, st!!); var em = msOf(date, en!!); if (em <= sm) em += 86_400_000L
        if (b > elapsedMin(sm, em)) err = "Break is longer than the elapsed time"
    }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Start / End / Break") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickTime(ctx, h24, st) { st = it } }, Modifier.fillMaxWidth()) { Text(st?.let { "Started work: ${fmtTod(it, h24)}" } ?: "Started work: set time") }
                OutlinedButton(onClick = { pickTime(ctx, h24, en) { en = it } }, Modifier.fillMaxWidth()) { Text(en?.let { "Finished work: ${fmtTod(it, h24)}" } ?: "Finished work: set time") }
                Text("If the finish time is earlier than the start, it counts as the next day (overnight).", style = MaterialTheme.typography.bodySmall)
                Field(brk, { brk = it }, "Lunch / break (minutes)", num = true, err = err)
                if (st != null || en != null) TextButton(onClick = { st = null; en = null }) { Text("Clear start and end") }
            }
        },
        confirmButton = {
            TextButton(enabled = err == null, onClick = {
                val sm = st?.let { msOf(date, it) }
                var em = en?.let { msOf(date, it) }
                if (sm != null && em != null && em <= sm) em += 86_400_000L
                vm.saveSession((sess ?: DailySession(date)).copy(startMs = sm, endMs = em, breakMin = b ?: 0)); onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
private fun BlockDialog(vm: Vm, date: Long, s: DayStat, ctx: android.content.Context, onClose: () -> Unit) {
    val h24 = vm.prefs.hour24
    val types = listOf("Break", "Other work", "Personal", "Waiting")
    var type by remember { mutableStateOf("Break") }
    var min by remember { mutableStateOf(s.unaccounted?.takeIf { it > 0 }?.toString() ?: "") }
    var tod by remember { mutableStateOf<Int?>(null) }
    var note by remember { mutableStateOf("") }
    val m = min.toIntOrNull()
    val un = s.unaccounted
    val err = if (min.isNotBlank() && (m == null || m <= 0 || m > 1440)) "Enter minutes between 1 and 1440"
    else if (m != null && un != null && m > un) "That is more than the unaccounted time (${fmtDur(un)})" else null
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Break / classify time") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Unaccounted time you do not classify stays \"Unknown\".", style = MaterialTheme.typography.bodySmall)
                Chips(types, type) { type = it }
                Field(min, { min = it }, "Minutes", num = true, err = err)
                OutlinedButton(onClick = { pickTime(ctx, h24, tod) { tod = it } }, Modifier.fillMaxWidth()) { Text(tod?.let { "At: ${fmtTod(it, h24)}" } ?: "Time of day (optional)") }
                Field(note, { note = it }, "Note (optional)")
            }
        },
        confirmButton = {
            TextButton(enabled = m != null && err == null, onClick = {
                var sm = tod?.let { msOf(date, it) }
                val sst = s.session?.startMs
                if (sm != null && sst != null && sm < sst) sm += 86_400_000L
                vm.addBlock(WorkBreak(date = date, minutes = m!!, type = type, startMs = sm, note = note.trim())); onClose()
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
