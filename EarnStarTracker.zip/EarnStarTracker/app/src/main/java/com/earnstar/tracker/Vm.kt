package com.earnstar.tracker

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class Screen(val tab: Int) {
    object Home : Screen(0)
    class Add(val editId: Long? = null, val date: Long = today(), val cat: Long? = null,
              val prefillDur: Int? = null, val prefillStart: Long? = null) : Screen(1)
    object History : Screen(2)
    class Day(val date: Long) : Screen(2)
    object Stats : Screen(3)
    class CatDetail(val id: Long) : Screen(3)
    object Settings : Screen(4)
    object Cats : Screen(4)
    class CatEdit(val id: Long?) : Screen(4)
}

class Vm(private val app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val dao = db.dao()
    val prefs = Prefs(app)

    val data: StateFlow<AppData?> = combine(dao.categories(), dao.entries(), dao.breakdowns(), dao.sessions(), dao.blocks()) { a, b, c, d, e ->
        AppData(a, b, c, d, e)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var screen by mutableStateOf<Screen>(Screen.Home)
    val stack = mutableStateListOf<Screen>()
    var toast by mutableStateOf<String?>(null)
    var pending by mutableStateOf<Parsed?>(null)

    init { Reminder.apply(app, prefs) }

    fun go(s: Screen) { stack.add(screen); screen = s }
    fun tab(i: Int) {
        stack.clear()
        screen = when (i) { 0 -> Screen.Home; 1 -> Screen.Add(); 2 -> Screen.History; 3 -> Screen.Stats; else -> Screen.Settings }
    }
    fun replaceDay(d: Long) { screen = Screen.Day(d) }
    fun back() { screen = if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) else Screen.Home }

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch { try { block() } catch (e: Exception) { toast = "Error: ${e.message}" } }
    }

    // ----- categories -----
    fun saveCategory(c: WorkCategory, done: () -> Unit = {}) = io {
        if (c.id == 0L) dao.insertCategory(c.copy(sortOrder = (data.value?.cats?.maxOfOrNull { it.sortOrder } ?: -1) + 1))
        else dao.updateCategory(c.copy(updatedAt = System.currentTimeMillis()))
        done()
    }
    fun deleteCategory(c: WorkCategory) = io {
        if (dao.entryCount(c.id) > 0) { dao.updateCategory(c.copy(active = false)); toast = "This work has records, so it was archived instead of deleted" }
        else dao.deleteCategory(c.id)
    }
    fun move(c: WorkCategory, dir: Int) {
        val l = data.value?.cats?.toMutableList() ?: return
        val i = l.indexOfFirst { it.id == c.id }; val j = i + dir
        if (i < 0 || j !in l.indices) return
        java.util.Collections.swap(l, i, j)
        io { l.forEachIndexed { k, x -> dao.updateCategory(x.copy(sortOrder = k)) } }
    }

    // ----- entries -----
    fun saveEntry(e: WorkEntry, bd: List<Pair<String, Double>>, done: () -> Unit) = io {
        db.withTransaction {
            val id = if (e.id == 0L) dao.insertEntry(e) else { dao.updateEntry(e.copy(updatedAt = System.currentTimeMillis())); dao.deleteBreakdowns(e.id); e.id }
            if (bd.isNotEmpty()) dao.insertBreakdowns(bd.map { WorkBreakdown(entryId = id, label = it.first, quantity = it.second) })
        }
        done()
    }
    fun deleteEntry(id: Long) = io { dao.deleteEntry(id) }

    // ----- timer (stored in Prefs, so it survives leaving screens, background and restarts) -----
    fun startTimer(cat: Long) = prefs.startTimer(cat, System.currentTimeMillis())
    fun stopTimer() = prefs.clearTimer()

    // ----- sessions / blocks / notes -----
    fun saveSession(s: DailySession) = io { dao.upsertSession(s.copy(updatedAt = System.currentTimeMillis())) }
    fun saveNote(date: Long, note: String) {
        val s = data.value?.sessionByDate?.get(date) ?: DailySession(date)
        saveSession(s.copy(note = note.trim()))
    }
    fun addBlock(b: WorkBreak) = io { dao.insertBlock(b) }
    fun deleteBlock(id: Long) = io { dao.deleteBlock(id) }
    private fun nowMin() = System.currentTimeMillis() / 60_000 * 60_000
    fun startDay() {
        val t = today(); val s = data.value?.sessionByDate?.get(t) ?: DailySession(t)
        val now = nowMin()
        val en = s.endMs
        saveSession(s.copy(startMs = now, endMs = if (en != null && en <= now) null else en))
    }
    fun endDay() {
        val t = today(); val s = data.value?.sessionByDate?.get(t)
        val st = s?.startMs
        if (s == null || st == null) { toast = "Tap Start Day first"; return }
        val now = nowMin()
        if (now <= st) { toast = "End time must be after the start time"; return }
        saveSession(s.copy(endMs = now))
    }

    // ----- backup / restore -----
    fun exportTo(uri: Uri, kind: String) = io {
        val d = data.value ?: return@io
        val text = when (kind) { "json" -> toJson(d); "csv" -> toCsv(d); else -> toReport(d, prefs.hour24) }
        withContext(Dispatchers.IO) { app.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) } }
        toast = "Export saved"
    }
    fun readImport(uri: Uri) = io {
        val text = withContext(Dispatchers.IO) { app.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }
        try { pending = parseBackup(text) } catch (e: Exception) { toast = "Backup rejected, nothing was changed: ${e.message}" }
    }
    fun confirmImport() {
        val p = pending ?: return
        pending = null
        io {
            data.value?.let { d -> withContext(Dispatchers.IO) { File(app.filesDir, "auto-backup-before-restore.json").writeText(toJson(d)) } }
            db.withTransaction {
                dao.clearEntries(); dao.clearSessions(); dao.clearBlocks(); dao.clearCategories()
                dao.putCategories(p.cats); dao.putEntries(p.entries); dao.putBreakdowns(p.bds); dao.putSessions(p.sessions); dao.putBlocks(p.blocks)
            }
            prefs.putSetupDone(true)
            toast = "Backup restored"
        }
    }

    // ----- data management -----
    fun wipeAll() = io {
        db.withTransaction { dao.clearEntries(); dao.clearSessions(); dao.clearBlocks(); dao.clearCategories() }
        prefs.putDefaultCat(-1); prefs.clearTimer()
        toast = "All data deleted"
    }
}
