package com.earnstar.tracker

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.YearMonth

// ================= HISTORY (days / calendar / search) =================
@Composable
fun HistoryScreen(vm: Vm, d: AppData) {
    var mode by rememberSaveable { mutableStateOf("Days") }
    ScreenList {
        item { Header("History") }
        item { Chips(listOf("Days", "Calendar", "Search"), mode) { mode = it } }
        when (mode) {
            "Days" -> daysList(vm, d)
            "Calendar" -> calendarView(vm, d)
            else -> searchView(vm, d)
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.daysList(vm: Vm, d: AppData) {
    item {
        var rng by rememberSaveable { mutableStateOf("This month") }
        var cf by rememberSaveable { mutableStateOf(today() - 6) }
        var ct by rememberSaveable { mutableStateOf(today()) }
        val ctx = LocalContext.current
        val (f, t) = rangeOf(rng, d, cf, ct)
        val ds = d.allDates.filter { it in f..t }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Chips(listOf("Today", "Yesterday", "This week", "This month", "Last month", "This year", "All time", "Custom"), rng) { rng = it }
            if (rng == "Custom") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickDate(ctx, cf) { cf = it } }, Modifier.weight(1f)) { Text("From ${fmtDate(cf)}") }
                OutlinedButton(onClick = { pickDate(ctx, ct) { ct = it } }, Modifier.weight(1f)) { Text("To ${fmtDate(ct)}") }
            }
            val ag = d.agg(f, t)
            Text("${fmtDate(f)} – ${fmtDate(t)} • ${ds.size} days • recorded ${fmtDur(ag.rec)} • elapsed ${fmtDur(ag.elapsed)}", style = MaterialTheme.typography.bodySmall)
            if (ds.isEmpty()) Text("No records in this period.")
            ds.forEach { dt -> DayRow(vm, d, dt) }
        }
    }
}

@Composable
private fun DayRow(vm: Vm, d: AppData, dt: Long) {
    val s = d.day(dt)
    Card2(onClick = { vm.go(Screen.Day(dt)) }) {
        Text(fmtDateLong(dt), fontWeight = FontWeight.Bold)
        Text((s.elapsed?.let { "${fmtDur(it)} elapsed • " } ?: "") + "${fmtDur(s.recorded)} recorded" + (s.unaccounted?.let { " • ${fmtDur(it)} unaccounted" } ?: ""))
        val q = d.cats.filter { s.qtyByCat.containsKey(it.id) }.joinToString("  ") { "${it.name} ${fmtNum(s.qtyByCat[it.id] ?: 0.0)} ${it.unit.lowercase()}" }
        if (q.isNotBlank()) Text(q, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(4.dp))
}

private fun androidx.compose.foundation.lazy.LazyListScope.calendarView(vm: Vm, d: AppData) {
    item {
        var ymS by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
        val ym = YearMonth.parse(ymS)
        val offset = ym.atDay(1).dayOfWeek.value - 1
        val green = Color(0xFF43A047); val amber = Color(0xFFFFB300)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ymS = ym.minusMonths(1).toString() }) { Icon(Icons.Filled.KeyboardArrowLeft, "Previous month") }
                Text(monthName(ym.atDay(1).toEpochDay()), Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { ymS = ym.plusMonths(1).toString() }) { Icon(Icons.Filled.KeyboardArrowRight, "Next month") }
            }
            Row { listOf("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su").forEach { Text(it, Modifier.weight(1f), style = MaterialTheme.typography.labelMedium) } }
            val cells = offset + ym.lengthOfMonth()
            for (r in 0 until (cells + 6) / 7) {
                Row {
                    for (c in 0 until 7) {
                        val n = r * 7 + c - offset + 1
                        if (n < 1 || n > ym.lengthOfMonth()) Box(Modifier.weight(1f).aspectRatio(1f))
                        else {
                            val day = ym.atDay(n).toEpochDay()
                            val st = d.dayState(day)
                            val bg = when (st) { 3 -> green.copy(alpha = 0.75f); 2 -> amber.copy(alpha = 0.75f); 1 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.3f); else -> Color.Transparent }
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).background(bg, CircleShape).clickable { vm.go(Screen.Day(day)) }, contentAlignment = Alignment.Center) {
                                Text(n.toString(), fontWeight = if (day == today()) FontWeight.ExtraBold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
            Text("Green: all daily targets reached • Amber: partly reached • Blue: work recorded • Empty: no work recorded", style = MaterialTheme.typography.bodySmall)
            Text("Tap a date to see its full summary.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.searchView(vm: Vm, d: AppData) {
    item {
        var q by rememberSaveable { mutableStateOf("") }
        val tokens = q.lowercase().split(" ").filter { it.isNotBlank() }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(q, { q = it }, "Search date, work, design, print, notes, \"16 dozen\"")
            if (tokens.isNotEmpty()) {
                val hits = d.entries.filter { e ->
                    val c = d.catById[e.categoryId]
                    val hay = (fmtDate(e.date) + " " + monthName(e.date) + " " + (c?.name ?: "") + " " + fmtNum(e.quantity) + " " + (c?.unit ?: "") + " " +
                        e.design + " " + e.notes + " " + d.bdByEntry[e.id].orEmpty().joinToString(" ") { it.label }).lowercase()
                    tokens.all { hay.contains(it) }
                }.sortedByDescending { it.date }
                val noteHits = d.sessions.filter { s ->
                    val hay = (fmtDate(s.date) + " " + monthName(s.date) + " " + s.note).lowercase()
                    s.note.isNotBlank() && tokens.all { hay.contains(it) }
                }.sortedByDescending { it.date }
                Text("${hits.size} entries, ${noteHits.size} day notes found", style = MaterialTheme.typography.bodySmall)
                noteHits.forEach { s -> Card2(onClick = { vm.go(Screen.Day(s.date)) }) { Text(fmtDate(s.date) + " • Day note", fontWeight = FontWeight.Bold); Text(s.note) } }
                hits.forEach { e ->
                    val c = d.catById[e.categoryId]
                    Card2(onClick = { vm.go(Screen.Day(e.date)) }) {
                        Text(fmtDate(e.date) + " • " + (c?.name ?: "?"), fontWeight = FontWeight.Bold)
                        Text("${fmtNum(e.quantity)} ${c?.unit?.lowercase() ?: ""}" + (if (e.design.isNotBlank()) " • ${e.design}" else ""))
                        if (e.notes.isNotBlank()) Text(e.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ================= STATISTICS =================
@Composable
fun StatsScreen(vm: Vm, d: AppData) {
    val ctx = LocalContext.current
    var rng by rememberSaveable { mutableStateOf("30 days") }
    var cf by rememberSaveable { mutableStateOf(today() - 29) }
    var ct by rememberSaveable { mutableStateOf(today()) }
    var workName by rememberSaveable { mutableStateOf("All work") }
    var grp by rememberSaveable { mutableStateOf("Daily") }
    val (f, t) = rangeOf(rng, d, cf, ct)
    val ag = d.agg(f, t)
    val cats = d.cats.filter { workName == "All work" || it.name == workName }
    val days = (t - f + 1).toInt().coerceAtLeast(1)
    ScreenList {
        item { Header("Statistics") }
        item { Chips(RANGES, rng) { rng = it } }
        if (rng == "Custom") item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickDate(ctx, cf) { cf = it } }, Modifier.weight(1f)) { Text("From ${fmtDate(cf)}") }
                OutlinedButton(onClick = { pickDate(ctx, ct) { ct = it } }, Modifier.weight(1f)) { Text("To ${fmtDate(ct)}") }
            }
        }
        item { Chips(listOf("All work") + d.cats.map { it.name }, workName) { workName = it } }
        item { Text("${fmtDate(f)} – ${fmtDate(t)}", style = MaterialTheme.typography.bodySmall) }
        item {
            Card2 {
                Text("Time", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Working days", ag.days.toString()); Tile("Elapsed", fmtDur(ag.elapsed))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Recorded", fmtDur(ag.rec), Color(0xFF2E7D32)); Tile("Unaccounted", fmtDur(ag.unacc), Color(0xFFEF6C00))
                }
                if (ag.days > 0) Text("Average elapsed per working day: ${fmtDur(ag.elapsed / ag.days)}")
                ag.bestDay?.let { Text("Best productivity day: ${fmtDate(it.first)} (${(it.second * 100).toInt()}% of available time recorded)") }
                val tot = (ag.rec + ag.brk + ag.other + ag.unacc).coerceAtLeast(1).toFloat()
                Text("Time distribution", fontWeight = FontWeight.Bold)
                HBar("Recorded work", fmtDur(ag.rec), ag.rec / tot, Color(0xFF2E7D32))
                HBar("Break", fmtDur(ag.brk), ag.brk / tot, Color(0xFF1E88E5))
                HBar("Other classified", fmtDur(ag.other), ag.other / tot, Color(0xFF8E24AA))
                HBar("Unaccounted", fmtDur(ag.unacc), ag.unacc / tot, Color(0xFFEF6C00))
            }
        }
        item { Text("Chart period", style = MaterialTheme.typography.labelLarge); Chips(listOf("Daily", "Weekly", "Monthly"), grp) { grp = it } }
        if (d.cats.isEmpty()) item { Text("Create a work type in Settings to see statistics.") }
        cats.forEach { c ->
            item(key = "cs${c.id}") {
                val cs = d.cat(c, f, t)
                Card2(onClick = { vm.go(Screen.CatDetail(c.id)) }) {
                    Text(c.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    if (cs.days == 0) Text("No entries in this period.") else {
                        Text("Total: ${fmtNum(cs.qty)} ${c.unit.lowercase()} in ${cs.days} days")
                        Text("Average/day: ${fmtNum(cs.perDay)} ${c.unit.lowercase()}" + (cs.perHour?.let { " • ${fmtNum(it)}/hour" } ?: ""))
                        cs.best?.let { Text("Highest day: ${fmtDate(it.key)} (${fmtNum(it.value)})") }
                        cs.worst?.let { Text("Lowest day: ${fmtDate(it.key)} (${fmtNum(it.value)})") }
                        Text("Output (${grp.lowercase()}, ${c.unit.lowercase()})", style = MaterialTheme.typography.labelMedium)
                        Bars(d.series(c, f, t, grp), c.unit.lowercase())
                    }
                    Text("Tap for full history of ${c.name}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            val tot = cats.sumOf { d.cat(it, f, t).recMin }.coerceAtLeast(1).toFloat()
            Card2 {
                Text("Work distribution (recorded time)", fontWeight = FontWeight.Bold)
                cats.forEach { c -> val m = d.cat(c, f, t).recMin; HBar(c.name, fmtDur(m), m / tot) }
                if (cats.all { d.cat(it, f, t).recMin == 0 }) Text("No time recorded on entries in this period.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Card2 {
                Text("Target vs actual (average per day)", fontWeight = FontWeight.Bold)
                var any = false
                cats.forEach { c ->
                    val tg = c.dailyTarget ?: return@forEach
                    if (tg <= 0) return@forEach
                    any = true
                    val cs = d.cat(c, f, t)
                    val avg = cs.qty / days
                    HBar("${c.name} actual", "${fmtNum(avg)} ${c.unit.lowercase()}", (avg / tg).toFloat(), Color(0xFF2E7D32))
                    HBar("${c.name} target", "${fmtNum(tg)} ${c.unit.lowercase()}", 1f, MaterialTheme.colorScheme.outline)
                }
                if (!any) Text("Set a daily target on a work type to compare.", style = MaterialTheme.typography.bodySmall)
                Text("Actual is spread over every day in the period, including days off.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ================= WORK-SPECIFIC HISTORY =================
@Composable
fun CatDetailScreen(vm: Vm, d: AppData, id: Long) {
    val c = d.catById[id]
    if (c == null) { Text("Work not found", Modifier.padding(16.dp)); return }
    val all = d.cat(c, Long.MIN_VALUE / 2, Long.MAX_VALUE / 2)
    val u = c.unit.lowercase()
    val t = today()
    val months = all.entries.groupBy { dateOf(it.date).year * 100 + dateOf(it.date).monthValue }.toSortedMap(compareByDescending<Int> { it })
        .map { (k, v) -> "${monthName(dateOf(k / 100, k % 100))}" to v.sumOf { it.quantity } }
    ScreenList {
        item { Header(c.name, onBack = { vm.back() }) { IconButton(onClick = { vm.go(Screen.CatEdit(c.id)) }) { Icon(Icons.Filled.Edit, "Edit work") } } }
        item {
            Card2 {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Tile("Days worked", all.days.toString()); Tile("Total $u", fmtNum(all.qty)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Tile("Total sets", fmtNum(all.sets)); Tile("Recorded time", fmtDur(all.recMin)) }
                Text("Average/day: ${fmtNum(all.perDay)} $u")
                Text("Average/hour: " + (all.perHour?.let { "${fmtNum(it)} $u" } ?: "not enough time data"))
                all.best?.let { Text("Best day: ${fmtDate(it.key)} (${fmtNum(it.value)} $u)") }
                all.worst?.let { Text("Lowest day: ${fmtDate(it.key)} (${fmtNum(it.value)} $u)") }
                Text("Trend (last 7 days vs the 7 before): ${d.trend(c)}", fontWeight = FontWeight.Bold)
            }
        }
        item {
            Card2 {
                Text("Targets", fontWeight = FontWeight.Bold)
                var any = false
                listOf("Day" to "Today", "Week" to "This week", "Month" to "This month").forEach { (p, label) ->
                    val tg = d.targetFor(c, p) ?: return@forEach
                    if (tg <= 0) return@forEach
                    any = true
                    val a = d.actualFor(c, p, t)
                    HBar("$label: ${fmtNum(a)} / ${fmtNum(tg)} $u", "${(a / tg * 100).toInt()}%", (a / tg).toFloat(), Color(0xFF2E7D32))
                }
                if (!any) Text("No targets set. Add them with the edit button.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (all.byDesign.isNotEmpty()) item {
            val mx = (all.byDesign.maxOfOrNull { it.second } ?: 1.0).toFloat()
            Card2 { Text("Design-wise", fontWeight = FontWeight.Bold); all.byDesign.forEach { (n, q) -> HBar(n, "${fmtNum(q)} $u", q.toFloat() / mx) } }
        }
        if (months.isNotEmpty()) item { Card2 { Text("Monthly totals", fontWeight = FontWeight.Bold); months.forEach { (m, q) -> Row { Text(m, Modifier.weight(1f)); Text("${fmtNum(q)} $u", fontWeight = FontWeight.Bold) } } } }
        item { Text("Recent entries", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (all.entries.isEmpty()) item { Text("No entries yet.") }
        items(all.entries.sortedWith(compareByDescending<WorkEntry> { it.date }.thenByDescending { it.createdAt }).take(15)) { e ->
            Card2(onClick = { vm.go(Screen.Add(editId = e.id)) }) {
                Text(fmtDate(e.date), fontWeight = FontWeight.Bold)
                Text("${fmtNum(e.quantity)} $u" + (e.design.takeIf { it.isNotBlank() }?.let { " • $it" } ?: "") + (e.durationMin?.let { " • ${fmtDur(it)}" } ?: ""))
            }
        }
    }
}

private fun dateOf(y: Int, m: Int): Long = java.time.LocalDate.of(y, m, 1).toEpochDay()

// ================= CATEGORIES =================
@Composable
fun CatsScreen(vm: Vm, d: AppData) {
    var del by remember { mutableStateOf<WorkCategory?>(null) }
    ScreenList {
        item { Header("Work types", onBack = { vm.back() }) }
        item { BigButton("+ Add work type") { vm.go(Screen.CatEdit(null)) } }
        if (d.cats.isEmpty()) item { Text("No work types yet.") }
        items(d.cats, key = { it.id }) { c ->
            Card2 {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name + if (c.active) "" else " (archived)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Unit: ${c.unit}" + (c.dailyTarget?.let { " • Daily target ${fmtNum(it)}" } ?: ""), style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { vm.move(c, -1) }) { Icon(Icons.Filled.KeyboardArrowUp, "Move up") }
                    IconButton(onClick = { vm.move(c, 1) }) { Icon(Icons.Filled.KeyboardArrowDown, "Move down") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.go(Screen.CatEdit(c.id)) }) { Text("Edit") }
                    OutlinedButton(onClick = { vm.saveCategory(c.copy(active = !c.active)) }) { Text(if (c.active) "Archive" else "Restore") }
                    OutlinedButton(onClick = { del = c }) { Text("Delete") }
                }
            }
        }
    }
    del?.let { c -> Confirm("Delete ${c.name}?", "If it has records it will only be archived, so your history is never lost. If it has none it is deleted.", onYes = { vm.deleteCategory(c); del = null }, onNo = { del = null }) }
}

@Composable
fun CatEditScreen(vm: Vm, d: AppData, id: Long?) {
    val existing = id?.let { d.catById[it] }
    ScreenList {
        item { Header(if (existing == null) "Add work type" else "Edit ${existing.name}", onBack = { vm.back() }) }
        item { CatForm(vm, d, existing, "Save") { vm.back() } }
    }
}

// ================= SETTINGS =================
@Composable
fun SettingsScreen(vm: Vm, d: AppData) {
    val ctx = LocalContext.current
    val p = vm.prefs
    var nameDraft by remember { mutableStateOf(p.appName) }
    var unitDraft by remember { mutableStateOf(p.defaultUnit) }
    var askWipe by remember { mutableStateOf(false) }
    var askClear by remember { mutableStateOf(false) }
    val jsonL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> if (u != null) vm.exportTo(u, "json") }
    val csvL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { u -> if (u != null) vm.exportTo(u, "csv") }
    val txtL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { u -> if (u != null) vm.exportTo(u, "txt") }
    val impL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.readImport(u) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun stamp() = java.time.LocalDate.now().toString()
    fun applyReminder() { Reminder.apply(ctx, p) }

    ScreenList {
        item { Header("Settings") }
        item { Card2(onClick = { vm.go(Screen.Cats) }) { Text("Work types", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium); Text("Add, edit, reorder, archive, change units and targets (${d.cats.size})") } }
        item {
            Card2 {
                Text("General", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Field(nameDraft, { nameDraft = it }, "App name")
                OutlinedButton(onClick = { if (nameDraft.isNotBlank()) { p.setAppName(nameDraft.trim()); vm.toast = "Saved" } }) { Text("Save app name") }
                Text("Theme"); Chips(listOf("System", "Light", "Dark"), p.theme.lowercase().replaceFirstChar { it.uppercase() }) { p.setTheme(it.uppercase()) }
                Text("Time format"); Chips(listOf("12 hour", "24 hour"), if (p.hour24) "24 hour" else "12 hour") { p.setHour24(it == "24 hour") }
                Field(unitDraft, { unitDraft = it }, "Default unit")
                OutlinedButton(onClick = { if (unitDraft.isNotBlank()) { p.setDefaultUnit(unitDraft.trim()); vm.toast = "Saved" } }) { Text("Save default unit") }
                Text("Default work category")
                Chips(d.cats.filter { it.active }.map { it.name }, d.catById[p.defaultCat]?.name) { n -> d.cats.firstOrNull { it.name == n }?.let { p.setDefaultCat(it.id) } }
            }
        }
        item {
            Card2 {
                Text("Reminder", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily \"Have you recorded today's work?\"", Modifier.weight(1f))
                    Switch(checked = p.reminderOn, onCheckedChange = { on ->
                        p.setReminderOn(on)
                        if (on && Build.VERSION.SDK_INT >= 33) permL.launch(Manifest.permission.POST_NOTIFICATIONS)
                        applyReminder()
                    })
                }
                OutlinedButton(onClick = { pickTime(ctx, p.hour24, p.reminderHour * 60 + p.reminderMin) { tod -> p.setReminderTime(tod / 60, tod % 60); applyReminder() } }) {
                    Text("Reminder time: ${fmtTod(p.reminderHour * 60 + p.reminderMin, p.hour24)}")
                }
                Text("Works offline. Android may deliver it a few minutes late to save battery.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Card2 {
                Text("Backup & restore", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Back up regularly. JSON is the file you can restore from.", style = MaterialTheme.typography.bodySmall)
                BigButton("Export JSON backup") { jsonL.launch("earnstar-backup-${stamp()}.json") }
                OutlinedButton(onClick = { csvL.launch("earnstar-export-${stamp()}.csv") }, Modifier.fillMaxWidth()) { Text("Export CSV") }
                OutlinedButton(onClick = { txtL.launch("earnstar-report-${stamp()}.txt") }, Modifier.fillMaxWidth()) { Text("Export readable report") }
                OutlinedButton(onClick = { impL.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Import / restore backup") }
            }
        }
        item {
            Card2 {
                Text("Data management", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("${d.entries.size} entries • ${d.sessions.size} day records • ${d.cats.size} work types", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { vm.loadSample() }, Modifier.fillMaxWidth()) { Text("Load sample data (empty app only)") }
                OutlinedButton(onClick = { askClear = true }, Modifier.fillMaxWidth(), enabled = p.sampleActive) { Text("Clear Sample Data") }
                OutlinedButton(onClick = { askWipe = true }, Modifier.fillMaxWidth()) { Text("Delete ALL data") }
            }
        }
        item {
            Card2 {
                Text("About", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("${p.appName} v1.0")
                Text("Personal, offline-first tracker. Your data stays on this phone and is never sent anywhere.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (askClear) Confirm("Clear sample data?", "All sample data will be removed so you start with an empty app.", "Clear", { askClear = false; vm.clearSample() }, { askClear = false })
    if (askWipe) Confirm("Delete ALL data?", "Every work type, entry, day record and note will be permanently deleted. Export a JSON backup first if unsure.", "Delete everything", { askWipe = false; vm.wipeAll() }, { askWipe = false })
}
