EarnStar Tracker (work + Time) - Android Studio project

1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder, then in Android Studio: File > Open > select the EarnStarTracker folder.
3. Wait for "Gradle sync" to finish (needs internet once, to download libraries).
4. Plug in your phone (USB debugging on) or start an emulator, then press the green Run button.
   To get an installable APK: Build > Build APK(s). The file appears under app/build/outputs/apk/debug/.

All data is stored on the phone only (Room database). Use Settings > Export JSON backup regularly.
